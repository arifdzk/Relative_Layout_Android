package com.example.dasarandro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        plus()
        min()
        next()
    }

//    fun textButton(){
//        var textHello :TextView = findViewById(R.id.textHello)
//        val buttonHello :Button = findViewById(R.id.btnHello)
//        Log.d("text", textHello.text.toString())
//
//        buttonHello.setOnClickListener{
//            textHello.text = "hello duniah"
//            Toast.makeText(this,"Berhasil Klik gan",Toast.LENGTH_LONG).show()
//        }
//    }

    fun plus(){
        var textHello :TextView = findViewById(R.id.textHello)
        val buttonHello :FloatingActionButton = findViewById(R.id.btnHello)

        buttonHello.setOnClickListener{
            var textInteger :Int = textHello.text.toString().toInt()
            textInteger+=1
            textHello.text= textInteger.toString()
        }
    }

    fun min(){
        var textHello2 :TextView = findViewById(R.id.textHello)
        val buttonHello2 :FloatingActionButton = findViewById(R.id.btnMinus)


        buttonHello2.setOnClickListener{
            var textInteger :Int = textHello2.text.toString().toInt()
            textInteger-=1

            if (textInteger<0){
                Toast.makeText(this,"Number Can't be Minus",Toast.LENGTH_LONG).show()

            }else{
                textHello2.text= textInteger.toString()
            }
        }
    }

    fun next(){
        val Next :Button = findViewById(R.id.btnNext)
        Next.setOnClickListener(View.OnClickListener { startActivity( Intent (this, NextActivity::class.java)) })
    }
}