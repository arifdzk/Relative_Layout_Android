package com.example.dasarandro

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class SiswaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_siswa)
        Kirim()
    }

    fun Kirim(){

        val buttonKirim : Button = findViewById(R.id.kirim)

       buttonKirim.setOnClickListener{
           Toast.makeText(this,"Berhasil",Toast.LENGTH_LONG).show()
      }
    }
}