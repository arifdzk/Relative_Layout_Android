package com.example.dasarandro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText

class NextActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_next)
        back()
        tambah()
        kurang()
        kali()
        bagi()
    }

    fun back(){
        val Next : Button = findViewById(R.id.btnBack)

        Next.setOnClickListener{
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }
    }
    fun kurang(){
        val Tambah: Button = findViewById(R.id.btnPlus)
        val angka1: EditText = findViewById(R.id.editText1)
        val angka2: EditText = findViewById(R.id.editText2)
        val hasil: EditText = findViewById(R.id.Hasil)

        Tambah.setOnClickListener{
            var Angka1:Int = angka1.text.toString().toInt()
            var Angka2:Int = angka2.text.toString().toInt()
            var Hasil:Int = 0
            Hasil = Angka1 - Angka2

            hasil.setText(Hasil.toString())

        }
    }
    fun tambah(){
        val Tambah: Button = findViewById(R.id.btnMin)
        val angka1: EditText = findViewById(R.id.editText1)
        val angka2: EditText = findViewById(R.id.editText2)
        val hasil: EditText = findViewById(R.id.Hasil)

        Tambah.setOnClickListener{
            var Angka1:Int = angka1.text.toString().toInt()
            var Angka2:Int = angka2.text.toString().toInt()
            var Hasil:Int = 0
            Hasil = Angka1 + Angka2

            hasil.setText(Hasil.toString())

        }
    }
    fun kali(){
        val Tambah: Button = findViewById(R.id.btnKali)
        val angka1: EditText = findViewById(R.id.editText1)
        val angka2: EditText = findViewById(R.id.editText2)
        val hasil: EditText = findViewById(R.id.Hasil)

        Tambah.setOnClickListener{
            var Angka1:Int = angka1.text.toString().toInt()
            var Angka2:Int = angka2.text.toString().toInt()
            var Hasil:Int = 0
            Hasil = Angka1 * Angka2

            hasil.setText(Hasil.toString())

        }
    }

    fun bagi(){
        val Tambah: Button = findViewById(R.id.btnBagi)
        val angka1: EditText = findViewById(R.id.editText1)
        val angka2: EditText = findViewById(R.id.editText2)
        val hasil: EditText = findViewById(R.id.Hasil)

        Tambah.setOnClickListener{
            var Angka1:Float = angka1.text.toString().toFloat()
            var Angka2:Float = angka2.text.toString().toFloat()
            var Hasil:Float = 0f
            Hasil = Angka1 / Angka2

            hasil.setText(Hasil.toString())

        }
    }
}